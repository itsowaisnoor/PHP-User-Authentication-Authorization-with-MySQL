<?php
	include('../config.php');
	BUNDLE::getLoginEssentials();
	BUNDLE::isAuthorized("1");
	
	
	if(isset($_SESSION['AUTH']))
	{
		$user = $_SESSION['AUTH'];
	}
	else if(isset($_COOKIE['AUTHCOOKIE']))
	{
		$user = base64_decode(base64_decode($_COOKIE['AUTHCOOKIE']));
	}
	else
	{
		$user = "";
	}

	echo "Welcome"." <b>".$user."</b>";
?>

<html>
	<head>
		<title>Profile</title>
	</head>
	<body>
		</br>
		</br>
		<a href="../logout.php">LOGOUT</a>
	</body>
</html>




















