<?php

class users{
		private $username, $password, $message, $defaulturl, $loginurl, $rememberme;
		
		function __construct()
		{
			$this->message = " ";
		}
		
		public function getUsername()
		{
			return $this->username;
		}
		public function getPassword()
		{
			return $this->password;
		}
		public function getMessage()
		{
			return $this->message;
		}
		public function getRememberme()
		{
			return $this->rememberme;
		}
		public function getDefaultUrl()
		{
			return $this->defaulturl;
		}
		public function getLoginUrl()
		{
			return $this->loginurl;
		}
		

		
		public function setUsername($param)
		{
			$this->username=$param;
		}
		
		public function setPassword($param)
		{
			$this->password=$param;
		}

		public function setMessage($param)
		{
			$this->message=$param;
		}
		public function setRememberme($param)
		{
			$this->rememberme=$param;
		}
		public function setDefaultUrl($param)
		{
			$this->defaulturl=$param;
		}
		public function setLoginUrl($param)
		{
			$this->loginurl=$param;
		}
			
}





?>