<?php
class processUsers
{
	private $connect;
	
	function __construct()
	{
		$this->connect=dbContext::Connect();
	}

	public function login($user)
	{
		if($this->isValid($user)){
			if($this->isAuthentic($user)){
					$this->isAuthorize($user);
			}else{
				
				$user->setMessage("Incorrect Username Or Password");
			}
		}
	}
	private function isValid($user)
	{
		if(!preg_match('%^[a-z]{2,20}$%',trim($user->getUsername()))){
			$user->setMessage("Invalid Characters Used For Username");
			return false;
		}
		if(!preg_match('%^[a-z]{2,20}$%',trim($user->getPassword()))){
			$user->setMessage("Invalid Characters Used For Password");
			return false;
		}
			return true;
	}
	private function isAuthentic($user)
	{
		$SQL = "SELECT `id` FROM `login` WHERE `username`='".$user->getUsername()."' AND
		`password`='".$user->getPassword()."' ";
			if($result = $this->connect->query($SQL))
			{
				if(mysqli_num_rows($result)!=0)
					return true;
					return false;
			}else
			{
				$user->setMessage("QUERY ERROR!");
			}
	}

	private function isAuthorize($user)
	{
		if($user->getRememberme()=="off")
		{
			$_SESSION['AUTH'] = $user->getUsername();
			header('location:'.$user->getDefaulturl());
		}
		else if($user->getRememberme() == "on")
		{
			setcookie("AUTHCOOKIE",base64_encode(base64_encode($user->getUsername())),time()+36000);
			header('location:'.$user->getDefaulturl());
		}
	}

}




?>