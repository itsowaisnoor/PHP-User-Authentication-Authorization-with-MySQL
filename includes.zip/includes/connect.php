<?php
	class dbContext
	{
		static function Connect()
		{
			$db = new mysqli(HOST,DBUSER,DBPASS,DBNAME);
				if($db->connect_errno)
					return false;
						return $db;
		}
	
	}



?>